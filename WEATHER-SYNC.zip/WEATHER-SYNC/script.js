const API_KEY = "10329f9a403c0b080204b1b82336806c";

const defaultCities = ["Lahore", "Islamabad", "Karachi", "Paris", "Sydney", "London"];

const grid = document.getElementById("weatherGrid");
const searchForm = document.getElementById("searchForm");
const searchInput = document.getElementById("searchInput");
const yearNow = document.getElementById("yearNow");

// Show loader
function showLoader(city) {
  grid.innerHTML += `
    <div class="card loader" id="loader-${city}">
      <div class="spinner"></div>
      <p>Loading ${city}...</p>
    </div>
  `;
}

// Remove loader
function removeLoader(city) {
  const loader = document.getElementById(`loader-${city}`);
  if (loader) loader.remove();
}

// Fetch current weather + forecast
async function fetchWeather(city) {
  try {
    showLoader(city);

    const res = await fetch(`https://api.openweathermap.org/data/2.5/weather?q=${city}&appid=${API_KEY}&units=metric`);
    const data = await res.json();
    if (data.cod !== 200) throw new Error(data.message);

    const forecastRes = await fetch(`https://api.openweathermap.org/data/2.5/forecast?q=${city}&appid=${API_KEY}&units=metric`);
    const forecastData = await forecastRes.json();

    removeLoader(city);
    renderCard(data, forecastData);
  } catch (err) {
    console.error(err);
    removeLoader(city);
    grid.innerHTML += `<div class="card error">⚠️ Could not load ${city}</div>`;
  }
}

function renderCard(weather, forecast) {
  const city = weather.name;
  const temp = Math.round(weather.main.temp);
  const icon = weather.weather[0].icon;
  const desc = weather.weather[0].description;

  const days = forecast.list.filter((_, i) => i % 8 === 0).slice(1, 4);

  const forecastHTML = days.map(d => {
    const dt = new Date(d.dt_txt);
    return `
      <div class="forecast-item">
        <p>${dt.toLocaleDateString(undefined, { weekday: "short" })}</p>
        <img src="https://openweathermap.org/img/wn/${d.weather[0].icon}.png" alt="">
        <p>${Math.round(d.main.temp)}°C</p>
      </div>
    `;
  }).join("");

  grid.innerHTML += `
    <div class="card">
      <h2>${city}</h2>
      <div class="weather-main">
        <img src="https://openweathermap.org/img/wn/${icon}@2x.png" alt="${desc}">
        <p class="temp">${temp}°C</p>
      </div>
      <p class="desc">${desc}</p>
      <div class="forecast">${forecastHTML}</div>
    </div>
  `;
}

// Search form
searchForm.addEventListener("submit", e => {
  e.preventDefault();
  const city = searchInput.value.trim();
  if (!city) return;
  grid.innerHTML = "";
  fetchWeather(city);
});

// Footer year
yearNow.textContent = new Date().getFullYear();

// Init load
grid.innerHTML = "";
defaultCities.forEach(fetchWeather);
